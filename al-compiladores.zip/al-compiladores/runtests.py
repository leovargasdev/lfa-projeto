import os
import sys

def erroTeste(mensagem = 'Erro no arquivo de teste. Leia "Como criar testes.md" para sanar dúvidas.'):
	raise Exception(mensagem)

def rodaTeste(nomeArquivo):
	criaArquivos(nomeArquivo)
	os.system('python3 al.py .input.tmp > .resposta_programa.tmp; diff -yZ --color=always .resultado.tmp .resposta_programa.tmp')

def criaArquivos(nomeArquivo):
	arquivo = open(nomeArquivo,'r').readlines()
	arquivoEntradaPrograma = open('.input.tmp', 'w')
	arquivoResultado = open('.resultado.tmp', 'w')

	numeroLinha = 1
	if '<Tokens>' not in arquivo[0]:
		erroTeste('Arquivo ' + nomeArquivo + ' não possui início em <Tokens>.')
	arquivoEntradaPrograma.write(str(arquivo.index('<Tabela>\n') - 1) + '\n')
	while numeroLinha < len(arquivo):
		if numeroLinha >= len(arquivo):
			erroTeste()
		linha = arquivo[numeroLinha]
		numeroLinha += 1
		if '<Tabela>' in linha:
			break
		arquivoEntradaPrograma.write(linha)

	while numeroLinha < len(arquivo):
		if numeroLinha >= len(arquivo):
			erroTeste()
		linha = arquivo[numeroLinha]
		numeroLinha += 1
		if '<Resposta>' in linha:
			break
		arquivoEntradaPrograma.write(linha)

	while numeroLinha < len(arquivo):
		linha = arquivo[numeroLinha]
		numeroLinha += 1
		arquivoResultado.write(linha)
	arquivoEntradaPrograma.close()
	arquivoResultado.close()

if len(sys.argv) > 1:
	rodaTeste(sys.argv[1])
else:
	print('\n==================== Arquivo: recursos/arquivo_teste.in ====================')
	rodaTeste('./recursos/arquivo_teste.in')
	for nomeArquivo in os.listdir('./tests/'):
		print('\n==================== Arquivo: ' + nomeArquivo + ' ====================')
		rodaTeste('./tests/' + nomeArquivo)
