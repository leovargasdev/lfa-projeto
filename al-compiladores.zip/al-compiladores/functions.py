from collections import defaultdict
from copy import deepcopy
from graphviz import *
from time import localtime, strftime

nTerminais = open("Gramatica/nao_terminais.txt").readlines()
terminais = open("Gramatica/terminais.txt").readlines()
regras = open("Gramatica/regras.txt").readlines()
estados = open("Gramatica/lalr_estados.txt").readlines()

def firstn():
    num = 3
    while True:
        yield num
        num += 1

uid = firstn()

def initDict():
    return defaultdict(f)
def f():
    return defaultdict(list)

def initDados():
    dados = {}
    dados['inicial'] = 1
    dados['erro'] = 2
    dados['final'] = []
    dados['eps'] = 'ε'
    dados['finais'] = {}
    dados['terminais'] = {}
    dados['nTerminais'] = {}
    dados['regras'] = []
    dados['estados'] = []
    return dados

def determiniza(grafo, dados, mapE, mapEI):
    # Novo grafo determinizado
    listAux = []    # Lista de estados do grafo que precisa ser percorrido
    listAux.append(dados['inicial'])
    grafoDet = initDict() # Grafo que será gerado ao fim da determinacao
    while True:
        flag = 1
        for E in listAux:
            grafoAux = deepcopy(grafo)
            for P in sorted(grafoAux[E]):
                if len(grafo[E][P]) > 1:
                    flag = 0
                    determinizaEstados(grafo, E, P, mapE, dados, grafoDet, listAux,mapEI);
                else: # caso em que nao foi encontrado Indeterminismo.
                    if grafo[E][P][0] not in grafoDet[E][P]:
                        grafoDet[E][P].append(grafo[E][P][0])
                    if grafo[E][P][0] not in listAux:
                        listAux.append(grafo[E][P][0])
        if flag:
            removeEstadosListaFinais(grafoDet,dados)
            removeEstadosInexistentesMapE(grafoDet,mapE,mapEI)
            return grafoDet


def determinizaEstados(grafoOriginal, estado, simbolo, indiceEstados, dados, grafoDeterminizado, filaEstados, mapEI):
    novoNome = newName(grafoOriginal[estado][simbolo],indiceEstados,mapEI)
    listName = grafoOriginal[estado][simbolo]
    if indiceEstados.get(novoNome) == None:
        novoNumero = next(uid)
        for estadoVizinho in grafoOriginal[estado][simbolo]:
            if estadoVizinho in dados['final'] and novoNumero not in dados['final']:
                dados['finais'][novoNumero] = dados['finais'][estadoVizinho]
                dados['final'].append(novoNumero)
            for arestaEstadoVizinho in grafoOriginal[estadoVizinho]:
                for k in grafoOriginal[estadoVizinho][arestaEstadoVizinho]:
                    if k not in grafoDeterminizado[novoNumero][arestaEstadoVizinho]:
                        grafoDeterminizado[novoNumero][arestaEstadoVizinho].append(k)
                        grafoOriginal[novoNumero][arestaEstadoVizinho].append(k)
        if len(grafoDeterminizado[estado][simbolo]) > 0:
             grafoDeterminizado[estado].pop(simbolo)
        grafoDeterminizado[estado][simbolo].append(novoNumero)
        grafoOriginal[estado].pop(simbolo)
        grafoOriginal[estado][simbolo].append(novoNumero)
        filaEstados.append(novoNumero)
        indiceEstados[novoNome] = novoNumero
        mapEI[novoNumero] = listName
    else:
        novoNumero = indiceEstados.get(novoNome)
        grafoOriginal[estado].pop(simbolo)
        grafoOriginal[estado][simbolo].append(novoNumero)
        if len(grafoDeterminizado[estado][simbolo]) > 0:
            grafoDeterminizado[estado].pop(simbolo)
        grafoDeterminizado[estado][simbolo].append(novoNumero)

def newName(listStates,mapE,mapEI):
    conjuntoName = set()
    for i in listStates:
        if mapEI.get(i) != None:
            for j in mapEI[i]:
                conjuntoName.add(j)
        else:
            conjuntoName.add(i)
    return ".".join(str(x) for x in sorted(list(conjuntoName)))

def removeEstadosInexistentesMapE(grafo,mapE,mapEI):
    l = []
    for i in mapE:
        if mapE[i] not in grafo:
            l.append(i)
    for i in l:
        mapE.pop(i)
    l = []
    for i in mapE:
        if type(i) == int:
            l.append(i)
    for i in l:
        mapE.pop(i)

def removeEstadosListaFinais(grafo,dados):
    l = []
    for i in dados['final']:
        teste = 0
        for E in grafo:
            for P in grafo[E]:
                if i in grafo[E][P]:
                    teste = 1
        if not teste:
            l.append(i)
    for j in l:
        dados['final'].remove(j)
    removeEstadoFinais(dados)

def removeEstadoFinais(dados):
    auxDict = deepcopy(dados['finais'])
    for i in auxDict:
        if i not in dados['final']:
            dados['finais'].pop(i)



def criamapEI(mapE):
    mapEI = {}
    for i in mapE:
        mapEI[int(mapE[i])] = [int(mapE[i])]
    return mapEI

def imprime(grafo,dados,renderiza=True,imprime = True):
    dot = Digraph(node_attr={ 'color': 'blue', 'fontcolor': 'blue' }, edge_attr={ 'color': 'gray', 'fontcolor': 'red' })
    for i in sorted(grafo):
        if imprime:
            print(str(i),"::= ", end="")
        dot.node(str(i))
        for j in sorted(grafo[i]):
            for k in sorted(grafo[i][j]):
                dot.edge(str(i), str(k), label=str(j))
                if imprime:
                    print(j or '.', str(k), sep='', end=" | ")
        if imprime:
            print()
    if renderiza:
        dot.render('resultados/' + strftime('%Y-%m-%d %H-%M-%S', localtime()), view=True, cleanup=True)


def lerArquivo(grafo, dados, mapE, mapEI, nomeArquivo):
    f = open(nomeArquivo).readlines()
    numToken = int(f[0])
    for i in f[1:numToken+1]:
        criaToken(grafo,dados,mapE,mapE,i)
    s = ""
    cont = True
    name = ""
    if len(f) > numToken+2:
        for i in f[numToken+1:]:
            if cont:
                name = i
                cont = False
            elif i == '\n':
                criaGramatica(grafo,dados,mapE,mapEI,s,name)
                cont = True
                s = ""
            else:
                s += i
        criaGramatica(grafo,dados,mapE,mapEI,s,name)

def confereGramatica(gramatica):
    gramatica = gramatica.split('analizadorLexico\n')[:-1]
    estados = []
    for l in gramatica:
        estados.append(splitEstados(l))
        producoes = splitProducoes(l)
        for i in producoes:
            if len(i) > 1 and i[1] == estados[0]:
                return True
    return False

def criaGramatica(grafo,dados,mapE,mapEI,gramatica,name):
    name = name.split('\n')[0]
    recursaoI = confereGramatica(gramatica)
    gramatica = gramatica.split("\n")[:-1] # Retira a quebra de linha da lista dos estados da gramatica.
    stateFinal = -1
    flag = False
    for l in gramatica:
        estado = splitEstados(l)
        numberState = dados['inicial'] if estado == 'S' else next(uid)
        mapE[estado], mapEI[numberState] = numberState, [numberState]
    if recursaoI: # Tratamento pra antiga função criaGramaticaRecursao
        newStateNumber = next(uid)
        mapE['SS'], mapEI[newStateNumber] = newStateNumber, [newStateNumber]
        print(newStateNumber)
        flag = True
    for l in gramatica:
        estado = splitEstados(l)
        producoes = splitProducoes(l)
        if flag:
            teste = "SS ::= "
            for k in producoes:
                teste += k + " | "
            teste = teste[:-3]
            gramatica.append(teste)
            flag = False
        numberState = mapE[estado]
        for p in producoes:
            terminal = p[0]
            if len(p) > 1:
                if recursaoI: # Tratamento pra antiga função criaGramaticaRecursao
                    stateProduction = 'SS' if p[1] == 'S' else p[1]
                else:
                    stateProduction = p[1]
                stateProduction = mapE[stateProduction]
            else:
                if p[0] == dados['eps']:
                    dados['finais'][mapE[estado]] = name
                    dados['final'].append(mapE[estado])
                else:
                    if stateFinal == -1:
                        stateFinal = next(uid)
                        dados['finais'][stateFinal] = name
                        dados['final'].append(stateFinal)
                    stateProduction = stateFinal
            if terminal != dados['eps']:
                grafo[numberState][terminal].append(stateProduction)


def splitEstados(linha):
    return linha.split(" ::= ")[0]

def splitProducoes(linha):
    return linha.split(" ::= ")[1].split(' | ')

def criaToken(grafo,dados,mapE,mapEI,token):
    nextE = next(uid)
    grafo[dados['inicial']][token[0]].append(nextE)
    mapE[str(nextE)] = nextE
    mapEI[nextE] = nextE
    for l in token[1:-1]:
        auxE = next(uid)
        mapE[str(auxE)] = auxE
        mapEI[auxE] = auxE
        grafo[nextE][l].append(auxE)
        nextE = auxE
    dados['finais'][nextE] = token[:-1]
    dados['final'].append(nextE)


###### FUNÇOES DO TRABALHO DE ANALISE LEXICA ######

class TabelaSimbolos():
    fita = []
    linhas = []
    numErros = 0
    def __str__ (self):
        for i in self.fita:
            print(i, end="")
        return ""

class SK():
    def __init__(self,estado,token,linha,var):
        self.estado = estado
        self.token = token
        self.linha = linha
        self.var = var
    def __str__(self):
        return "Linha: " + "{:5}".format(str(self.linha)) + " Rotulo: " + "{:10}".format(self.var) + " Estado Final: " + "{:5}".format(str(self.estado)) + " Token: " + "{:5}".format(self.token) + "\n"

# def initDados():
#     dados['inicial'] = 1, dados['erro'] = 2, dados['final'] = []
#     dados['eps'] = 'ε', ['finais'] = {}, dados['terminais'] = {}
#     dados['nTerminais'] = {}, dados['regras'] = [], dados['estados'] = []

def analizadorLexico(AFD, fonte, dados): #fonte = arquivo de entrada, dados = initDados()
    tabela = TabelaSimbolos()
    estado = dados['inicial']
    linha = 0
    var = ""
    flag = False
    for i in fonte:
        tabela.linhas.append(i)
        linha += 1
        for j in i:
            if not flag:
                if j == " " or j == "\n":
                    if estado in dados['final']:
                        tabela.fita.append(SK(estado,dados['finais'][estado],linha,var))
                        estado = dados['inicial']
                        var = ""
                elif len(AFD[estado][j]) > 0:
                    var += j
                    estado = AFD[estado][j][0]
                else:
                    var += j
                    flag = True
            else:
                if j == " " or j == "\n":
                    tabela.fita.append(SK(dados['erro'],'erro',linha,var))
                    tabela.numErros += 1
                    estado = dados['inicial']
                    var = ""
                    flag = False
                else:
                    var += j
    for i in tabela.fita:
        if(i.estado == 2):
            print("File 'entrada.brijl', line ",i.linha," in <module>")
            print("    ",tabela.linhas[i.linha-1],end="")
            print("SyntaxError: invalid syntax")
            exit()
    return tabela

def trataTerminais(n):
    l = []
    for i in n:
        i = i.replace("\n","")
        i = i.split(" ")
        l.append(i)
    return l

def trataRegras(n):
    l = []
    for i in n:
        i = i.replace("\n","")
        i = i.split("  ")
        l.append(i)
    return l

def trataEstados(n):
    l = []
    a = []
    for i in n:
        i = i.replace("\n", "")
        i = i.split("State .*")
        if('' not in i):
            a.append(i)
        else:
            l.append(a)
            a = []
    l.append(a)
    return l

def initListParser():
    return defaultdict(initParser)

def initParser():
    d = dict()
    global nTerminais
    global terminais
    for i in terminais:
        d[i[1]] = []
    for i in nTerminais:
        d[i[1]] = []
    return d

def preencheParser(estados,parser):
    cont = 0
    for i in estados:
        for j in i:
            for k in j:
                k = k.split(" ")
                if(k[0] == "State"):
                    cont = int(k[1])
                    parser[cont]
                elif(k[0] == '$' and len(k) == 2):
                    parser[cont][k[0]].append(k[1])
                else:
                    parser[cont][k[0]].append(k[1]+k[2])
        cont += 1

def initTableParser():
    global nTerminais
    global terminais
    global regras
    global estados

    nTerminais = trataTerminais(nTerminais)
    terminais = trataTerminais(terminais)
    regras = trataRegras(regras)
    estados = trataEstados(estados)
    parser = initListParser()
    preencheParser(estados,parser)
    return parser

def tamanhoRegra(regra):
    regra = regra[0].split("::=")
    if(len(regra[1]) > 0):
        regra = regra[1].split(" ")
        return len(regra)-1
    return 0

def retornaEstado(regra):
    regra = regra[0].split(" ")
    return regra[1]

def retornaTopoPilha(pilha):
    pos = len(pilha) - 1
    if(pos % 2 == 0):
        return int(pilha[pos])
    return pilha[pos]

def tratarErros(parser,topP,firstF,pilha,fita):
    pass

def analisadorSintatico(ff, parser, dados):
    global nTerminais
    global terminais
    global regras
    pilha = []
    pilha.append(0)
    fita = deepcopy(ff.fita)
    # printParser(parser)
    while(1):
        topP = retornaTopoPilha(pilha)
        if(len(fita) != 0):
            firstF = str(fita[0].token)
        else:
            fita.append(SK("1","$",1,"$"))
            firstF = '$'
        if(len(pilha) < 10):
            print("HEAP:  ", pilha)
        else:
            print("HEAP:  ", pilha[len(pilha)-10:])
        if(len(fita) < 10):
            cont = 0
            print("QUEUE: [", end="")
            for i in fita:
                cont += 1
                if(cont == len(fita)):
                    print(i.token,end="")
                else:
                    print(i.token,end=", ")
            print("]")
        else:
            cont = 0
            print("QUEUE: [", end="")
            for i in fita:
                cont += 1
                if(cont == 9):
                    print(i.token,end="")
                else:
                    print(i.token,end=", ")
                if(cont == 9):
                    break
            print("]")
        print("ACTION:", parser[topP][firstF])
        print("--------------------------------------------------------------------------------")

        # print(topP,firstF)
        # print(pilha, fita)
        # print(parser[topP][firstF])
        # print(parser[1]['var'])
        if(len(parser[topP][firstF]) == 0): # Em caso de erro.
            print(" - Error on Parsing Proccess")
            print("Erro sintático na linha: ", fita[0].linha)
            # tratarErros(parser,topP,firstF,pilha,fita)
            exit()
        elif(parser[topP][firstF][0] == "ac"): # Em caso de aceitação
            return
        elif(parser[topP][firstF][0][0] == "s"): # Em caso de transferencia.
            # print(parser[topP][firstF][0])
            pilha.append(firstF)
            pilha.append(int(parser[topP][firstF][0][1:]))
            fita.pop(0)
        elif(parser[topP][firstF][0][0] == "r"): # Em caso de redução
            # print(parser[topP][firstF][0])
            tam = tamanhoRegra(regras[int(parser[topP][firstF][0][1:])])
            tam *= 2
            pilha = pilha[0:len(pilha)-tam]
            pilha.append(retornaEstado(regras[int(parser[topP][firstF][0][1:])]))
            pilha.append(int(parser[pilha[len(pilha)-2]][pilha[len(pilha)-1]][0][1:]))

def printParser(parser):
    for i in parser:
        print(i,end=" ")
        for j in parser[i]:
            if(len(parser[i][j]) > 0):
                print(j," ",parser[i][j][0], end="")
                print("| ",end="")
        print()
