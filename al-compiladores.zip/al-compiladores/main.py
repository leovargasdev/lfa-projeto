from functions import *
import sys
import time

AFD = initDict()
dados = initDados()
mapE = {}
mapEI = {}
lerArquivo(AFD,dados,mapE,mapEI, sys.argv[1] if len(sys.argv) > 1 else './tokens.txt')
mapEI = criamapEI(mapE)
AFD = determiniza(AFD,dados,mapE,mapEI)
# imprime(AFD,dados,imprime=False) #para nao imprimir no terminal o grafo.
# imprime(AFD,dados, renderiza=False) # se não quiser gerar o PDF
# print("Lista de Estados e qual Indeterminismo foi resolvido: ", end="")
# print(mapEI)
# print()
# print("Estados Finais: ", end="")
# print(sorted(dados['final']))
# print()
# print("Finais/token: ", end="")
# print(dados['finais'])
# print()
# print()
fonte = open("entrada.brijl")
# print("[Compiler Log File]:")
# print()
# print("[Starting Lexical Analyser]")
tabelaSimbolos = analizadorLexico(AFD,fonte,dados)
print("tabelaSimbolos")
print(tabelaSimbolos)
# print(" - Lexical Analysis Completed Without Errors")
# parser = initTableParser()
# print()
# print("[Initiating Syntactic Analysis]")
# analisadorSintatico(tabelaSimbolos,parser,dados)
# print(" - Parsing Successfully Completed")
